from django.test import TestCase,Client
from django.urls import reverse
from datetime import datetime

from Account_Module.models import User,Profile
from ..models import Post

class TestBlogView(TestCase):

    def setUp(self):
        self.client = Client()
        self.user_obj = User.objects.create_user(phone=9182021314,email='test@test.com',password='admin') 
        self.profile_obj = Profile.objects.create(user=self.user_obj,first_name='test_f',last_name='test_l',description='test_test')
        self.post_obj = Post.objects.create(
            author = self.profile_obj,
            title = 'test',
            content = 'test_test',
            status = True,
            category = None,
            published_date = datetime.now()
        )

    def test_blog_index_url_successful_response(self):

        url = reverse('post:index')
        response = self.client.get(url)
        self.assertEquals(response.status_code,200)
        self.assertTrue(str(response.content).find('index'))
        self.assertTemplateUsed(response,template_name='index.html')

    def test_blog_post_detail_logged_in_response(self):

        self.client.force_login(self.user_obj)
        url = reverse('post:post-detail',kwargs={'pk':self.post_obj.id})
        response = self.client.get(url)
        self.assertEquals(response.status_code,200)

    def test_blog_post_detail_anonymous_response(self):

        url = reverse('post:post-detail',kwargs={'pk':self.post_obj.id})
        response = self.client.get(url)
        self.assertEquals(response.status_code,302)