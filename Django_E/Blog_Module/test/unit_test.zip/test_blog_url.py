from django.test import TestCase,Client
from django.urls import reverse,resolve
from ..views import PostList,DetailPost


class TestUrlListPost(TestCase):

    def test_blog_list_post(self):
        url = reverse('post:post-list')
        self.assertEquals(resolve(url).func.view_class,PostList)
    
    def test_blog_detail_post(self):
        url = reverse('post:post-detail',kwargs={'pk':2})
        self.assertEquals(resolve(url).func.view_class,DetailPost)


