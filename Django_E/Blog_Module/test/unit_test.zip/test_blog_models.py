from django.test import TestCase
from datetime import datetime

from Account_Module.models import User,Profile
from ..models import Post

class TestPostModel(TestCase):

    def setUp(self):
        self.user_obj = User.objects.create_user(phone=9182021314,email='test@test.com',password='admin') 
        self.profile_obj = Profile.objects.create(user=self.user_obj,first_name='test_f',last_name='test_l',description='test_test')

    def test_create_post_with_valid_data(self):
    
        post_obj = Post.objects.create(
            author = self.profile_obj,
            title = 'test',
            content = 'test_test',
            status = True,
            category = None,
            published_date = datetime.now()
        )

        self.assertTrue(Post.objects.filter(pk=post_obj.id).exists())
